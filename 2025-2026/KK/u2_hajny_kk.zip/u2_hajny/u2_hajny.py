# Spusteni: python u2_hajny.py "c:\cesta\k\soutezici.csv" (bez parametru bere soutezici.csv v aktualni slozce)
import sys,csv
from datetime import datetime

try: import matplotlib.pyplot as plt
except ImportError: sys.exit("Chyba: chybí matplotlib (pip install matplotlib)")

# Nacteni a kontrola dat
p=sys.argv[1] if len(sys.argv)>1 else "soutezici.csv";fmt="%Y-%m-%d %H:%M:%S";V=[];A=[]
try:
    with open(p,encoding="utf-8-sig",newline="") as f:
        s=f.readline()
        if not s: sys.exit("Chyba: prázdný soubor")
        d=";" if ";" in s else ","
        f.seek(0)
        for i,r in enumerate(csv.reader(f,delimiter=d),1):
            if not r or all(not x.strip() for x in r): continue
            if len(r)<2: sys.exit(f"Chyba: řádek {i} nemá 2 sloupce")
            try: v=datetime.strptime(r[0].strip(),fmt);a=datetime.strptime(r[1].strip(),fmt)
            except ValueError: sys.exit(f"Chyba: špatný formát času na řádku {i}")
            if a<v: sys.exit(f"Chyba: akce předchází výzvě (řádek {i})")
            V.append(v);A.append(a)
except OSError as e: sys.exit(f"Chyba: {e}")
if not V: sys.exit("Chyba: žádná data")

def cnt(ts,n,f):
    c=[0]*n
    for t in ts: c[f(t)]+=1
    return c

dv=cnt(V,1440,lambda t:t.hour*60+t.minute);da=cnt(A,1440,lambda t:t.hour*60+t.minute)
wv=cnt(V,10080,lambda t:t.weekday()*1440+t.hour*60+t.minute);wa=cnt(A,10080,lambda t:t.weekday()*1440+t.hour*60+t.minute)
ds=[(a-v).total_seconds()/86400 for v,a in zip(V,A)];lim=14;big=sum(x>lim for x in ds);shown=[x for x in ds if x<=lim]

# Vykresleni grafu
fig=plt.figure(figsize=(12,9),constrained_layout=True);gs=fig.add_gridspec(3,2,height_ratios=[1,1,1.2])
ax_dv=fig.add_subplot(gs[0,0]);ax_da=fig.add_subplot(gs[0,1]);ax_wv=fig.add_subplot(gs[1,0]);ax_wa=fig.add_subplot(gs[1,1]);ax_dt=fig.add_subplot(gs[2,:])

def plot(ax,c,title,xt,xtl,xlab,xm):
    ax.plot(c,lw=1);ax.set(title=title,xlabel=xlab,ylabel="Počet");ax.set_xlim(0,xm);ax.set_xticks(xt,xtl);ax.grid(axis="x",color="0.85")
    m=max(c) if c else 0;ax.set_ylim(0,m*1.1+1)

plot(ax_dv,dv,"Výzva – denní čas",range(0,1440,120),[f"{h:02d}:00" for h in range(0,24,2)],"Denní čas",1439)
plot(ax_da,da,"Akce – denní čas",range(0,1440,120),[f"{h:02d}:00" for h in range(0,24,2)],"Denní čas",1439)
for ax in (ax_dv,ax_da):
    ax.set_xticks(range(0,1440,60),minor=True);ax.grid(axis="x",which="minor",color="0.92");ax.tick_params(axis="x",labelrotation=45,labelsize=8)
dny="Po Út St Čt Pá So Ne".split()
plot(ax_wv,wv,"Výzva – týdenní čas",range(0,10080,1440),dny,"Čas v týdnu",10079)
plot(ax_wa,wa,"Akce – týdenní čas",range(0,10080,1440),dny,"Čas v týdnu",10079)

n,_,_=ax_dt.hist(shown,bins=lim*24,range=(0,lim),color="#ff7f0e")
ax_dt.set(title="Odstup akce od výzvy",xlabel="Dny",ylabel="Počet",xlim=(0,lim));ax_dt.set_xticks(range(lim+1));ax_dt.grid(axis="x",color="0.85")
ax_dt.text(.99,.95,f">{lim} dnů: {big}",transform=ax_dt.transAxes,ha="right",va="top")
ax_dt.set_ylim(0,(max(n) if len(n) else 0)*1.1+1)

plt.show()
