a=list(map(int,input().split()))
c=[[0]*16]+[[abs(i//4-(x-1)//4)+abs(i%4-(x-1)%4)for i in range(16)]for x in range(1,16)]
m=[]
for i in range(16):
 r=[]
 if i>3:r+=[(i-4,'N','D')]
 if i<12:r+=[(i+4,'D','N')]
 if i%4:r+=[(i-1,'L','P')]
 if i%4<3:r+=[(i+1,'P','L')]
 m+=[r]
z=a.index(0)
if(sum(a[i]>a[j]>0 for i in range(16) for j in range(i+1,16))+z//4)%2<1:print("Neexistuje");print()
else:
 h=sum(c[x][i]for i,x in enumerate(a));p=[];b=h
 def f(g,h,z,k):
  if g+h>b:return g+h
  if not h:return 1
  n=99
  for q,t,o in m[z]:
   if t!=k:
    x=a[q];a[z]=x;a[q]=0;p.append(t)
    r=f(g+1,h+c[x][z]-c[x][q],q,o)
    if r==1:return 1
    p.pop();a[q]=x;a[z]=0
    if r<n:n=r
  return n
 while 1:
  n=f(0,h,z,'')
  if n==1:print(len(p));print(''.join(p));break
  b=n
