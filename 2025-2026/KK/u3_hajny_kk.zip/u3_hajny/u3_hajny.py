from pathlib import Path
import sys
from PIL import Image


def vyber_png(slozka: Path) -> Path:
    soubory = sorted(slozka.glob("*.png"))
    if not soubory:
        raise ValueError("Ve slozce nejsou zadne PNG soubory.")
    for i, soubor in enumerate(soubory, 1):
        print(f"{i}. {soubor.name}")
    vyber = int(input("Vyber cislo obrazku: "))
    if vyber < 1 or vyber > len(soubory):
        raise ValueError("Neplatne cislo souboru.")
    return soubory[vyber - 1]


def cernobily_obrazek(img: Image.Image, cil: Path) -> None:
    rgb = img.convert("RGB")
    w, h = rgb.size
    zdroj = rgb.load()
    bw = Image.new("RGB", (w, h), "white")
    vystup = bw.load()
    # Mapa pokladu: cerny pixel jen pokud jsou R i G liche.
    for y in range(h):
        for x in range(w):
            r, g, _ = zdroj[x, y]
            vystup[x, y] = (0, 0, 0) if (r & 1 and g & 1) else (255, 255, 255)
    bw.save(cil)


def desifruj(img: Image.Image) -> list[str]:
    rgb = img.convert("RGB")
    w, h = rgb.size
    px = rgb.load()
    zpravy: list[str] = []
    for y in range(h):
        radek = ""
        for x in range(0, w - w % 4, 4):
            bity = "".join("1" if (px[x + i, y][2] & 1) else "0" for i in range(4))
            if bity == "1111":
                if x == 0 and not radek:
                    return zpravy
                if radek:
                    zpravy.append(radek)
                break
            hodnota = int(bity, 2)
            if hodnota > 9:
                raise ValueError(f"Neplatna ctverice {bity} na radku {y + 1}, sloupci {x + 1}.")
            radek += str(hodnota)
        else:
            if radek:
                raise ValueError(f"Na radku {y + 1} chybi ukoncovaci ctverice 1111.")
    return zpravy


def main() -> None:
    try:
        slozka = Path(sys.argv[1] if len(sys.argv) > 1 else input("Zadej cestu ke slozce: ").strip())
        if not slozka.is_dir():
            raise ValueError("Zadana cesta neni slozka.")
        obrazek = vyber_png(slozka)
        with Image.open(obrazek) as img:
            cil = obrazek.with_name(f"{obrazek.stem}_bw.png")
            cernobily_obrazek(img, cil)
            sifry = desifruj(img)
        if not sifry:
            raise ValueError("V obrazku nebyla nalezena zadna platna ciselna sifra.")
        print(f"Cernobila mapa ulozena do: {cil}")
        print("Nalezena sifra:")
        print("\n".join(sifry))
    except Exception as e:
        print(f"Chyba: {e}")


if __name__ == "__main__":
    main()
