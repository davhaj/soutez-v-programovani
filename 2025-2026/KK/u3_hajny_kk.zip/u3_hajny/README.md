## u3_hajny

Pozadovany navrh alternativy:
`Kdyby se upravilo ukladani dat tak, aby vygenerovany cernobily obraz nesl text primo, bylo by mozne pouzit OCR modul pytesseract (Tesseract) a cisla cist automaticky bez vlastniho bitoveho dekoderu.`
