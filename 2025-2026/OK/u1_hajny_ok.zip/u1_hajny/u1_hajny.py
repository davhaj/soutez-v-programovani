import json
import sys
from pathlib import Path


def norm(word):
    return word.strip().casefold()


def first_letter_from_norm(n):
    return "ch" if n.startswith("ch") else n[0]


def last_letter_from_norm(n):
    return "ch" if n.endswith("ch") else n[-1]


def first_letter(word):
    n = norm(word)
    return first_letter_from_norm(n) if n else ""


def last_letter(word):
    n = norm(word)
    return last_letter_from_norm(n) if n else ""


def load_words(path):
    if path.suffix.lower() == ".json":
        data = json.loads(path.read_text(encoding="utf-8"))
        words = [str(w) for w in data]
    else:
        words = path.read_text(encoding="utf-8").splitlines()

    by_start = {}
    seen = set()
    for w in words:
        w = w.strip()
        if not w:
            continue
        n = norm(w)
        if not n or n in seen:
            continue
        seen.add(n)
        key = first_letter_from_norm(n)
        by_start.setdefault(key, []).append((n, w))
    return by_start


def pick_word(letter, by_start, used):
    lst = by_start.get(letter)
    if not lst:
        return None
    while lst:
        n, w = lst.pop()
        if n not in used:
            used.add(n)
            return w
    return None


def main():
    base = Path(__file__).resolve().parent
    default_path = base / "01_slovni_fotbal_hra" / "stredne.txt"
    path_input = input(f"Cesta k wordlistu (Enter = {default_path}): ").strip()
    path = Path(path_input) if path_input else default_path
    try:
        by_start = load_words(path)
    except OSError:
        print(f"Nelze nacist slovnik: {path}", file=sys.stderr)
        return 1
    except json.JSONDecodeError:
        print(f"Neplatny JSON slovnik: {path}", file=sys.stderr)
        return 1

    used = set()

    word = input("Zadej prvni slovo (Enter = vzdavam): ").strip()
    if not word:
        return 0
    n = norm(word)
    if not n:
        return 0
    used.add(n)
    need = last_letter_from_norm(n)

    while True:
        comp = pick_word(need, by_start, used)
        if not comp:
            print("Nemam slovo. Vyhral jsi.")
            return 0
        print(f"Pocitac: {comp}")
        need = last_letter(comp)

        word = input(f"Na {need}: ").strip()
        if not word:
            print("Vzdal ses. Vyhral jsem.")
            return 0
        n = norm(word)
        if not n:
            print("Prazdne slovo. Konec.")
            return 0
        if n in used:
            print("To slovo uz bylo. Prohral jsi.")
            return 0
        if first_letter_from_norm(n) != need:
            print(f"Musi zacinat na {need}. Prohral jsi.")
            return 0
        used.add(n)
        need = last_letter_from_norm(n)


if __name__ == "__main__":
    raise SystemExit(main())
