import json
import sys
from pathlib import Path


def norm(word):
    return word.strip().casefold()


def first_letter(n):
    return "ch" if n.startswith("ch") else n[0]


def last_letter(n):
    return "ch" if n.endswith("ch") else n[-1]


def main():


    path_input = input("Cesta k wordlistu: ").strip()
    if not path_input:
        return 0
    path = Path(path_input)
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        print("NE, nejde.")
        return 0

    if path.suffix.lower() == ".json":
        try:
            words = [str(w) for w in json.loads(text)]
        except json.JSONDecodeError:
            print("NE, nejde.")
            return 0
    else:
        words = text.splitlines()

    adj = {}
    indeg = {}
    outdeg = {}
    und = {}
    vertices = set()
    edge_count = 0

    for w in words:
        w = w.strip()
        if not w:
            continue
        n = norm(w)
        if not n:
            continue
        a = first_letter(n)
        b = last_letter(n)
        adj.setdefault(a, []).append((b, w))
        outdeg[a] = outdeg.get(a, 0) + 1
        indeg[b] = indeg.get(b, 0) + 1
        vertices.add(a)
        vertices.add(b)
        if a != b:
            und.setdefault(a, set()).add(b)
            und.setdefault(b, set()).add(a)
        else:
            und.setdefault(a, set())
        edge_count += 1

    if edge_count == 0:
        print("ANO, jde:")
        return 0

    start = None
    end = None
    for v in vertices:
        out_v = outdeg.get(v, 0)
        in_v = indeg.get(v, 0)
        diff = out_v - in_v
        if diff == 1:
            if start is not None:
                print("NE, nejde.")
                return 0
            start = v
        elif diff == -1:
            if end is not None:
                print("NE, nejde.")
                return 0
            end = v
        elif diff != 0:
            print("NE, nejde.")
            return 0

    if start is None:
        start = next(iter(vertices))

    seen = {start}
    stack = [start]
    while stack:
        v = stack.pop()
        for u in und.get(v, ()):
            if u not in seen:
                seen.add(u)
                stack.append(u)
    if seen != vertices:
        print("NE, nejde.")
        return 0

    path = []
    stack = [(start, None)]
    while stack:
        v, w = stack[-1]
        lst = adj.get(v)
        if lst:
            u, word = lst.pop()
            stack.append((u, word))
        else:
            stack.pop()
            if w is not None:
                path.append(w)

    if len(path) != edge_count:
        print("NE, nejde.")
        return 0

    path.reverse()
    out = ["ANO, jde:"]
    out.extend(path)
    sys.stdout.write("\n".join(out))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
