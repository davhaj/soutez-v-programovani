import math
import time
from datetime import datetime, timedelta
import tkinter as tk
from tkinter import messagebox

CANVAS = 200
R = 90


class Clock:
    def __init__(self, parent, name, mode, offset_hours=0.0, manual_secs=0):
        self.frame = tk.Frame(parent, bd=1, relief="groove", padx=6, pady=6)
        self.label = tk.Label(self.frame, text=name)
        self.label.pack()
        self.canvas = tk.Canvas(self.frame, width=CANVAS, height=CANVAS, bg="white", highlightthickness=0)
        self.canvas.pack()

        self._draw_face()
        self.set_config(name, mode, offset_hours, manual_secs)

    def _draw_face(self):
        c = CANVAS // 2
        self.canvas.create_oval(c - R, c - R, c + R, c + R, width=2)
        for n in range(1, 13):
            ang = n / 12 * 2 * math.pi - math.pi / 2
            x = c + (R - 18) * math.cos(ang)
            y = c + (R - 18) * math.sin(ang)
            self.canvas.create_text(x, y, text=str(n))

    def set_config(self, name, mode, offset_hours=0.0, manual_secs=0):
        self.name = name
        self.mode = mode
        self.offset_hours = float(offset_hours)
        if mode == "manual":
            self.base_secs = manual_secs % 86400
            self.base_real = time.time()
        self.label.config(text=name)

    def _seconds_now(self):
        if self.mode == "offset":
            dt = datetime.now() + timedelta(hours=self.offset_hours)
            return (dt.hour * 3600 + dt.minute * 60 + dt.second + dt.microsecond / 1e6) % 86400
        return (self.base_secs + (time.time() - self.base_real)) % 86400

    def update(self):
        secs = self._seconds_now()
        s = secs % 60
        m = (secs / 60) % 60
        h = (secs / 3600) % 12
        c = CANVAS // 2

        self.canvas.delete("hands")

        def hand(length, frac, width, color):
            ang = frac * 2 * math.pi - math.pi / 2
            x = c + length * math.cos(ang)
            y = c + length * math.sin(ang)
            self.canvas.create_line(c, c, x, y, width=width, fill=color, tags="hands")

        hand(R * 0.5, h / 12, 4, "black")
        hand(R * 0.75, m / 60, 3, "black")
        hand(R * 0.85, s / 60, 1, "red")
        self.canvas.create_oval(c - 3, c - 3, c + 3, c + 3, fill="black", outline="", tags="hands")


def parse_time(txt):
    if not txt.strip():
        return 0
    parts = txt.strip().split(":")
    if len(parts) not in (2, 3):
        raise ValueError
    h = int(parts[0])
    m = int(parts[1])
    s = int(parts[2]) if len(parts) == 3 else 0
    if not (0 <= h < 24 and 0 <= m < 60 and 0 <= s < 60):
        raise ValueError
    return h * 3600 + m * 60 + s


def clock_dialog(parent, title, init=None):
    data = {
        "name": "",
        "mode": "offset",
        "offset": "0",
        "manual": "00:00:00",
    }
    if init:
        data.update(init)

    win = tk.Toplevel(parent)
    win.title(title)
    win.transient(parent)
    win.grab_set()

    tk.Label(win, text="Name").grid(row=0, column=0, sticky="w", padx=6, pady=4)
    name_var = tk.StringVar(value=data["name"])
    tk.Entry(win, textvariable=name_var, width=22).grid(row=0, column=1, padx=6, pady=4)

    mode_var = tk.StringVar(value=data["mode"])
    tk.Radiobutton(win, text="Offset from local time", variable=mode_var, value="offset").grid(
        row=1, column=0, columnspan=2, sticky="w", padx=6
    )
    tk.Radiobutton(win, text="Manual time", variable=mode_var, value="manual").grid(
        row=2, column=0, columnspan=2, sticky="w", padx=6
    )

    tk.Label(win, text="Offset (hours)").grid(row=3, column=0, sticky="w", padx=6, pady=4)
    offset_var = tk.StringVar(value=data["offset"])
    tk.Entry(win, textvariable=offset_var, width=22).grid(row=3, column=1, padx=6, pady=4)

    tk.Label(win, text="Manual time (HH:MM:SS)").grid(row=4, column=0, sticky="w", padx=6, pady=4)
    manual_var = tk.StringVar(value=data["manual"])
    tk.Entry(win, textvariable=manual_var, width=22).grid(row=4, column=1, padx=6, pady=4)

    result = {}

    def ok():
        name = name_var.get().strip() or "Clock"
        mode = mode_var.get()
        try:
            off = float(offset_var.get().strip() or 0)
            man = parse_time(manual_var.get())
        except Exception:
            messagebox.showerror("Error", "Invalid offset or manual time format.")
            return
        result.update({"name": name, "mode": mode, "offset": off, "manual": man})
        win.destroy()

    def cancel():
        win.destroy()

    btns = tk.Frame(win)
    btns.grid(row=5, column=0, columnspan=2, pady=6)
    tk.Button(btns, text="OK", width=8, command=ok).pack(side="left", padx=4)
    tk.Button(btns, text="Cancel", width=8, command=cancel).pack(side="left", padx=4)

    win.wait_window()
    return result or None


def main():
    root = tk.Tk()
    root.title("Analog Clocks")

    left = tk.Frame(root)
    left.pack(side="left", fill="y", padx=8, pady=8)

    tk.Label(left, text="Clocks").pack(anchor="w")
    listbox = tk.Listbox(left, height=12, width=22)
    listbox.pack(fill="y", pady=4)

    btn_frame = tk.Frame(left)
    btn_frame.pack(fill="x", pady=4)

    display_canvas = tk.Canvas(root, bd=0, highlightthickness=0)
    display_canvas.pack(side="left", fill="both", expand=True)
    scrollbar = tk.Scrollbar(root, orient="vertical", command=display_canvas.yview)
    scrollbar.pack(side="right", fill="y")
    display_canvas.configure(yscrollcommand=scrollbar.set)

    inner = tk.Frame(display_canvas)
    display_canvas.create_window((0, 0), window=inner, anchor="nw")

    def on_configure(_):
        display_canvas.configure(scrollregion=display_canvas.bbox("all"))

    inner.bind("<Configure>", on_configure)

    clocks = []

    def refresh_list():
        listbox.delete(0, tk.END)
        for c in clocks:
            listbox.insert(tk.END, c.name)

    def layout_clocks():
        for i, c in enumerate(clocks):
            r, col = divmod(i, 2)
            c.frame.grid(row=r, column=col, padx=8, pady=8)

    def add_clock():
        data = clock_dialog(root, "Add clock")
        if not data:
            return
        c = Clock(inner, data["name"], data["mode"], data["offset"], data["manual"])
        clocks.append(c)
        refresh_list()
        layout_clocks()
        listbox.selection_clear(0, tk.END)
        listbox.selection_set(tk.END)

    def edit_clock():
        sel = listbox.curselection()
        if not sel:
            return
        i = sel[0]
        c = clocks[i]
        data = clock_dialog(
            root,
            "Edit clock",
            {
                "name": c.name,
                "mode": c.mode,
                "offset": str(c.offset_hours),
                "manual": time.strftime("%H:%M:%S", time.gmtime(c._seconds_now()))
                if c.mode == "manual"
                else "00:00:00",
            },
        )
        if not data:
            return
        c.set_config(data["name"], data["mode"], data["offset"], data["manual"])
        refresh_list()

    def remove_clock():
        sel = listbox.curselection()
        if not sel:
            return
        i = sel[0]
        clocks[i].frame.destroy()
        del clocks[i]
        refresh_list()
        layout_clocks()

    tk.Button(btn_frame, text="Add", command=add_clock).pack(fill="x")
    tk.Button(btn_frame, text="Edit", command=edit_clock).pack(fill="x", pady=4)
    tk.Button(btn_frame, text="Remove", command=remove_clock).pack(fill="x")

    # default clock
    c0 = Clock(inner, "Local", "offset", 0.0, 0)
    clocks.append(c0)
    refresh_list()
    layout_clocks()
    listbox.selection_set(0)

    def tick():
        for c in clocks:
            c.update()
        root.after(50, tick)

    tick()
    root.mainloop()


if __name__ == "__main__":
    main()
